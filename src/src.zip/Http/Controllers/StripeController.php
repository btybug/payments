<?php
/**
 * Created by PhpStorm.
 * User: menq
 * Date: 11.01.2018
 * Time: 13:49
 */

namespace BtyBugHook\Payments\Http\Controllers;


use App\Http\Controllers\Controller;

class StripeController extends Controller
{
    public function getIndex()
    {


        dd(1);

    }
}