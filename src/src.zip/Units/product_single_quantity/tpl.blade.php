<div class="product-single-quantity">
    <p>Quantity:</p>
    <input type="number" min="1" step="1" value="1">
    <div class="quantity-nav">
        <div class="quantity-button quantity-up"><i class="fa fa-plus" aria-hidden="true"></i></div>
        <div class="quantity-button quantity-down"><i class="fa fa-minus" aria-hidden="true"></i></div>
    </div>
</div>
{!! BBstyle($_this->path."/css/main.css") !!}
{!!  BBscript($_this->path.'/js/main.js') !!}