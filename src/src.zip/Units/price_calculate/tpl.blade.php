<div class="product-single-price">
    <h6>Price</h6>
    <p>$12</p>
</div>
{!! BBstyle($_this->path."/css/main.css") !!}
{!!  BBscript($_this->path.'/js/main.js') !!}