<div class="row">


    <!-- Multiple Checkboxes -->
    <div class="form-group my_rows1">
        <label for="newcontainer" class="col-sm-4 labelTitle">Payment Gateways</label>
        <div class="col-sm-8">
            {!! BBbutton2('unit','buttons','payment_gateway_buttons','Select Buttons',['class'=>'form-control input-md','model'=>$settings]) !!}
        </div>
    </div>

</div>