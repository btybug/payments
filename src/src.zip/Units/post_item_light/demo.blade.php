<div class="container">
    <div class="row">
        <div class="post-item-light">
            <div class="col-md-4 col-sm-4 col-xs-12">
                <div class="plan-box">
                    <div class="plan-options">
                        <div class="plan-icon">
                            <img src="https://cdn.shopify.com/s/files/1/1223/5758/products/janhoustoncamo1_2048x2048.jpg"
                                 alt="">
                        </div>
                        <div class="plan-name">
                            <span>Product name</span>
                        </div>
                        <div class="plan-price">
                            <span>$500</span>
                        </div>
                        <div class="button">
                            <a class="" href="#">Add To Cart<i class="fa fa-shopping-cart" aria-hidden="true"></i></a>
                            <a class="" href="#">View Product<i class="fa fa-eye" aria-hidden="true"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
{!! BBstyle($_this->path."/css/main.css") !!}
{!!  BBscript($_this->path.'/js/main.js') !!}