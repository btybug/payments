@php
    $col = posts_url_manager();
@endphp

{!! BBstyle($_this->path."/css/main.css") !!}
{!!  BBscript($_this->path.'/js/main.js') !!}