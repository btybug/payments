@php
    $col = posts_url_manager();
@endphp
taxxx
{!! BBstyle($_this->path."/css/main.css") !!}
{!!  BBscript($_this->path.'/js/main.js') !!}