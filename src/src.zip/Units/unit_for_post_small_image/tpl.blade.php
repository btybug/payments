<div>
    <img src="https://render.fineartamerica.com/images/rendered/search/print/images-medium-5/happy-bear-stephen-stookey.jpg" alt="">
</div>