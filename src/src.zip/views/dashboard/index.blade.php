@extends('btybug::layouts.admin')
@section('content')
    <div class="main_lay_cont">
        {!! 'Dashboard' !!}
    </div>

@stop
@section('CSS')
@stop
@section('JS')
@stop
