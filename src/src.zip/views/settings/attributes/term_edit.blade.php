@extends('btybug::layouts.admin')
@section('content')
    <div class="container">
       @include("payments::settings.attributes.terms_create_or_update")
    </div>
@stop
@section('CSS')
@stop
@section('JS')

@stop
