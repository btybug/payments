<div class="form-group">
    <div class="col-md-6">
        Price
    </div><div class="col-md-6">
        {!! Form::text('price',null,['class' => 'form-control']) !!}
    </div>
</div>